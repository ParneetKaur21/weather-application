const apiKey = 'd0ddb2d266624755846446d8d30941b8';

// === Theme Toggle ===
function toggleTheme() {
    document.body.classList.toggle('dark-mode');
}

// === Utility: Convert Moon Phase ===
function phaseToEmojiText(phase) {
    if (phase === 0 || phase === 1) return ["🌑", "New Moon"];
    if (phase > 0 && phase < 0.25) return ["🌒", "Waxing Crescent"];
    if (phase === 0.25) return ["🌓", "First Quarter"];
    if (phase > 0.25 && phase < 0.5) return ["🌔", "Waxing Gibbous"];
    if (phase === 0.5) return ["🌕", "Full Moon"];
    if (phase > 0.5 && phase < 0.75) return ["🌖", "Waning Gibbous"];
    if (phase === 0.75) return ["🌗", "Last Quarter"];
    return ["🌘", "Waning Crescent"];
}

// === Render Moon Card ===
function renderMoonCard(dayData) {
    const [emoji, name] = phaseToEmojiText(dayData.moon_phase);
    document.getElementById("moon-emoji").textContent = emoji;
    document.getElementById("moon-phase-name").textContent = name;

    const formatTime = ts => new Date(ts * 1000).toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
    });

    document.getElementById("moonrise-time").textContent = formatTime(dayData.moonrise);
    document.getElementById("moonset-time").textContent = formatTime(dayData.moonset);
    document.getElementById("moon-card").classList.remove("hidden");
}

// === Update UI with Weather Data ===
function updateWeatherUI(data) {
    document.getElementById("location").textContent = `📍 ${data.name}, ${data.sys.country}`;

    const nowUTC = new Date(new Date().getTime() + new Date().getTimezoneOffset() * 60000);
    const cityTime = new Date(nowUTC.getTime() + data.timezone * 1000);
    const options = {
        weekday: "short",
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true
    };
    document.getElementById("date").textContent = cityTime.toLocaleString("en-US", options);

    document.getElementById("temperature").textContent = `${Math.round(data.main.temp)}°C`;
    const condition = data.weather[0].main;
    document.getElementById("condition").textContent = condition;

    document.getElementById("pressure").textContent = `${data.main.pressure} hPa`;
    document.getElementById("humidity").textContent = `${data.main.humidity}%`;
    document.getElementById("wind").textContent = `${data.wind.speed} m/s`;

    const iconMap = {
        Clear: "☀️",
        Clouds: "☁️",
        Rain: "🌧️",
        Drizzle: "🌦️",
        Thunderstorm: "⛈️",
        Snow: "❄️",
        Mist: "🌫️",
        Smoke: "🌫️",
        Haze: "🌫️",
        Dust: "🌫️",
        Fog: "🌫️",
        Sand: "🌫️",
        Ash: "🌋",
        Squall: "🌬️",
        Tornado: "🌪️"
    };

    const weatherIcon = iconMap[condition] || "🌈";
    document.getElementById("current-weather-icon").textContent = weatherIcon;

    updateAdviceCard(condition);
}

// === Update Advice Card ===
function updateAdviceCard(condition) {
    const adviceCard = document.getElementById("advice-card");
    const adviceImage = document.getElementById("advice-image");
    const adviceText = document.getElementById("advice-text");

    const adviceMap = {
        Clear: {
            text: "It's sunny! 😎",
            img: "https://img.freepik.com/free-photo/cloud-blue-sky_1232-3108.jpg"
        },
        Rain: {
            text: "Take your umbrella! ☔",
            img: "https://img.freepik.com/free-photo/closeup-shot-wet-glass-reflecting-rainy-forest-scenery_181624-23365.jpg"
        },
        Clouds: {
            text: "It’s cloudy. Wear a jacket.",
            img: "https://img.freepik.com/free-photo/black-rain-abstract-dark-power_1127-2380.jpg"
        },
        default: {
            text: "Have a nice day!",
            img: "https://img.freepik.com/free-photo/hands-with-nice-text-flowers_24837-57.jpg"
        }
    };

    const advice = adviceMap[condition] || adviceMap.default;
    adviceImage.src = advice.img;
    adviceText.textContent = advice.text;
    adviceCard.classList.remove("hidden");
}

// === Fetch Moon Data ===
function fetchMoonData(lat, lon) {
    fetch(`https://api.openweathermap.org/data/2.5/onecall?lat=${lat}&lon=${lon}&exclude=hourly,current,minutely,alerts&units=metric&appid=${apiKey}`)
        .then(res => res.json())
        .then(data => {
            if (data.daily && data.daily.length) {
                renderMoonCard(data.daily[0]);
            }
        })
        .catch(console.error);
}

// === Fetch Weather by Coordinates ===
function fetchWeatherByCoords(lat, lon) {
    fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${apiKey}`)
        .then(res => res.json())
        .then(data => {
            if (data.cod === 200) {
                updateWeatherUI(data);
                fetchMoonData(lat, lon);
            } else {
                alert("Weather data not found.");
            }
        })
        .catch(console.error);
}

// === Fetch Weather by City ===
function fetchWeatherByCity(city) {
    fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`)
        .then(res => res.json())
        .then(data => {
            if (data.cod === 200) {
                updateWeatherUI(data);
                fetchMoonData(data.coord.lat, data.coord.lon);
            } else {
                alert("City not found.");
            }
        })
        .catch(console.error);
}

// === Get Current Location Weather ===
function getCurrentLocationWeather() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const {
                    latitude,
                    longitude
                } = position.coords;
                fetchWeatherByCoords(latitude, longitude);
            },
            () => {
                alert("Unable to get your location. Please enter a city manually.");
            }
        );
    } else {
        alert("Geolocation is not supported by this browser.");
    }
}

// === Forecast Cards Filler ===
function updateForecastDates() {
    const container = document.getElementById("forecast-container");
    container.innerHTML = "";
    const icons = ["☀️", "🌦️", "🌧️", "⛅", "🌩️", "☁️"];
    let today = new Date();

    for (let i = 1; i <= 10; i++) {
        let date = new Date();
        date.setDate(today.getDate() + i);
        const dateStr = date.toLocaleDateString("en-US", {
            month: "short",
            day: "numeric"
        });
        const randomIcon = icons[Math.floor(Math.random() * icons.length)];
        const dayDiv = document.createElement("div");
        dayDiv.className = "forecast-day";
        dayDiv.innerHTML = `<strong>${dateStr}</strong><br>${randomIcon}<br><small>24°C / 16°C</small>`;
        container.appendChild(dayDiv);
    }
}

// === Search Weather ===
function searchWeather() {
    const city = document.getElementById("search-input").value.trim();
    if (city) {
        fetchWeatherByCity(city);
    } else {
        alert("Enter a city name.");
    }
}

// === Start App: Switch Page ===
function startApp() {
    document.getElementById("home-page").classList.add("hidden");
    document.getElementById("forecast-page").classList.remove("hidden");
    updateForecastDates();
    getCurrentLocationWeather();
    setInterval(updateDateTime, 60000);
}

// === Update Date Every Minute ===
function updateDateTime() {
    const now = new Date();
    const options = {
        weekday: "short",
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
    };
    document.getElementById("date").textContent = now.toLocaleString("en-US", options);
}

// === Voice Search ===
function startVoiceSearch() {
    if (!('webkitSpeechRecognition' in window)) {
        alert("Sorry, browser doesn't support speech recognition.");
        return;
    }
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.start();

    recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript;
        document.getElementById("search-input").value = transcript;
        searchWeather();
    };

    recognition.onerror = function(event) {
        alert('Voice error: ' + event.error);
    };
}

// === Typing Text Effect ===
const typingText = document.getElementById("typing-text");
const textToType = "Check weather of any location!";
let i = 0;

function typeText() {
    if (i < textToType.length) {
        typingText.textContent += textToType.charAt(i);
        i++;
        setTimeout(typeText, 80);
    }
}

window.onload = typeText;

// === Enter Key Search Event Listener ===
document.getElementById("search-input").addEventListener("keypress", function(e) {
    if (e.key === "Enter") searchWeather();
});